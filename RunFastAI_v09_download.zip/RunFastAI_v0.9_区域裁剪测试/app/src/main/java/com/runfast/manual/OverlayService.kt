package com.runfast.manual

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var bubble: TextView? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var statusText: TextView
    private var previewImage: ImageView? = null
    private var ownCropImage: ImageView? = null
    private var leftCropImage: ImageView? = null
    private var rightCropImage: ImageView? = null
    private var status = "尚未开始屏幕采集"
    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            status = intent?.getStringExtra("status") ?: status
            if (::statusText.isInitialized) statusText.text = status
            val bitmap = CaptureFrameStore.latestBitmap
            if (bitmap != null && !bitmap.isRecycled) previewImage?.setImageBitmap(bitmap)
            CaptureFrameStore.ownHandCrop?.let { if (!it.isRecycled) ownCropImage?.setImageBitmap(it) }
            CaptureFrameStore.leftOpponentCrop?.let { if (!it.isRecycled) leftCropImage?.setImageBitmap(it) }
            CaptureFrameStore.rightOpponentCrop?.let { if (!it.isRecycled) rightCropImage?.setImageBitmap(it) }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble == null && panel == null) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val filter = IntentFilter(CaptureService.ACTION_STATUS)
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, filter, RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") registerReceiver(statusReceiver, filter)
            showBubble()
        }
        return START_STICKY
    }

    private fun windowType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun showBubble() {
        bubbleParams = WindowManager.LayoutParams(dp(34), dp(34), windowType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END; x = dp(6); y = dp(150)
        }
        val b = TextView(this).apply {
            text = "AI"; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            alpha = 0.82f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xDD1565C0.toInt()); setStroke(dp(1), Color.WHITE) }
            setOnClickListener { removeBubble(); showPanel() }
        }
        bubble = b; wm.addView(b, bubbleParams); makeDraggable(b, bubbleParams)
    }

    private fun removeBubble() { bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null }

    private fun showPanel() {
        val width = dp(286)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(9), dp(8), dp(9), dp(8))
            background = GradientDrawable().apply { setColor(0xEE17212B.toInt()); cornerRadius = dp(12).toFloat(); setStroke(dp(1), 0xFF6C8BA8.toInt()) }
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply { text = "跑得快 AI"; textSize = 14f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(Button(this).apply { text = "收起"; textSize = 10f; setOnClickListener { collapse() } })
        box.addView(top)
        statusText = TextView(this).apply { text = status; textSize = 11f; setTextColor(0xFFE2EAF2.toInt()); setPadding(0, dp(8), 0, dp(8)) }
        box.addView(statusText)
        box.addView(TextView(this).apply {
            text = "实时采集画面预览（仅本机内存）"
            textSize = 10f; setTextColor(0xFFB8C7D6.toInt()); setPadding(0, dp(2), 0, dp(4))
        })
        previewImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFF080D12.toInt())
            val bitmap = CaptureFrameStore.latestBitmap
            if (bitmap != null && !bitmap.isRecycled) setImageBitmap(bitmap)
        }
        box.addView(previewImage, LinearLayout.LayoutParams(-1, dp(142)))
        box.addView(TextView(this).apply {
            text = "区域裁剪预览（初始范围，待截图校准）"
            textSize = 10f; setTextColor(0xFFB8C7D6.toInt()); setPadding(0, dp(5), 0, dp(3))
        })
        val cropRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun cropTile(label: String, bitmap: android.graphics.Bitmap?, assign: (ImageView) -> Unit): LinearLayout {
            return LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(this@OverlayService).apply { text = label; textSize = 9f; gravity = Gravity.CENTER; setTextColor(Color.WHITE) })
                addView(ImageView(this@OverlayService).apply {
                    scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(0xFF080D12.toInt())
                    if (bitmap != null && !bitmap.isRecycled) setImageBitmap(bitmap)
                    assign(this)
                }, LinearLayout.LayoutParams(-1, dp(58)))
            }
        }
        cropRow.addView(cropTile("我的手牌", CaptureFrameStore.ownHandCrop) { ownCropImage = it }, LinearLayout.LayoutParams(0, -2, 1f))
        cropRow.addView(cropTile("左侧对手", CaptureFrameStore.leftOpponentCrop) { leftCropImage = it }, LinearLayout.LayoutParams(0, -2, 1f))
        cropRow.addView(cropTile("右侧对手", CaptureFrameStore.rightOpponentCrop) { rightCropImage = it }, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(cropRow)
        box.addView(TextView(this).apply {
            text = "当前阶段：区域裁剪初测\n自动识牌：尚未实现\n出牌推荐：尚未启用\n裁剪范围为临时估算，需用真实截图校准；画面仅保留于内存，不保存、不上传。"
            textSize = 10f; setTextColor(0xFFB8C7D6.toInt()); setPadding(0, dp(5), 0, dp(2))
        })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply { text = "关闭面板"; textSize = 10f; setOnClickListener { collapse() } }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(this).apply { text = "关闭助手"; textSize = 10f; setOnClickListener { stopService(Intent(this@OverlayService, CaptureService::class.java)); stopSelf() } }, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(actions)
        val params = WindowManager.LayoutParams(width, WindowManager.LayoutParams.WRAP_CONTENT, windowType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END; x = dp(4); y = dp(110)
        }
        panel = box; wm.addView(box, params)
    }

    private fun collapse() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null; showBubble()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun makeDraggable(view: android.view.View, params: WindowManager.LayoutParams) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        view.setOnTouchListener { _, e -> when (e.action) {
            MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = params.x; oy = params.y; true }
            MotionEvent.ACTION_MOVE -> { params.x = (ox - (e.rawX - sx)).toInt().coerceAtLeast(0); params.y = (oy + (e.rawY - sy)).toInt().coerceAtLeast(0); try { wm.updateViewLayout(view, params) } catch (_: Exception) {}; true }
            MotionEvent.ACTION_UP -> { if (kotlin.math.abs(e.rawX - sx) < dp(5) && kotlin.math.abs(e.rawY - sy) < dp(5)) view.performClick(); true }
            else -> true
        } }
    }

    override fun onDestroy() {
        try { unregisterReceiver(statusReceiver) } catch (_: Exception) {}
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; bubble = null; previewImage = null
        ownCropImage = null; leftCropImage = null; rightCropImage = null
        super.onDestroy()
    }
}

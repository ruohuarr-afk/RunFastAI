package com.runfast.manual

import android.graphics.Bitmap
import android.graphics.Rect

/** Provisional normalized regions for the confirmed A-layout landscape table.
 * Coordinates are intentionally adjustable after a real gameplay screenshot is reviewed.
 */
object RegionCropper {
    data class Crops(val ownHand: Bitmap, val leftOpponent: Bitmap, val rightOpponent: Bitmap)

    fun crop(frame: Bitmap): Crops {
        val w = frame.width
        val h = frame.height
        // A-layout: own cards at bottom; opponents at upper-left and upper-right.
        // These are broad first-pass windows, not final card-level boxes.
        val own = rect(w, h, 0.10f, 0.66f, 0.90f, 0.99f)
        val left = rect(w, h, 0.00f, 0.00f, 0.40f, 0.43f)
        val right = rect(w, h, 0.60f, 0.00f, 1.00f, 0.43f)
        return Crops(
            Bitmap.createBitmap(frame, own.left, own.top, own.width(), own.height()),
            Bitmap.createBitmap(frame, left.left, left.top, left.width(), left.height()),
            Bitmap.createBitmap(frame, right.left, right.top, right.width(), right.height())
        )
    }

    private fun rect(w: Int, h: Int, l: Float, t: Float, r: Float, b: Float): Rect {
        val left = (w * l).toInt().coerceIn(0, w - 1)
        val top = (h * t).toInt().coerceIn(0, h - 1)
        val right = (w * r).toInt().coerceIn(left + 1, w)
        val bottom = (h * b).toInt().coerceIn(top + 1, h)
        return Rect(left, top, right, bottom)
    }
}

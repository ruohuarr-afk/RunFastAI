package com.runfast.camera

/**
 * OCR 字符清洗与点数候选提取。
 * 注意：这只是 OCR 后处理，不是完整扑克牌视觉识别。
 */
object CardRankParser {
    private val tokenRegex = Regex("(?i)(10|[3-9]|[AJQK]|2)")
    private val validRanks = setOf("3","4","5","6","7","8","9","10","J","Q","K","A","2")

    fun parse(ocrText: String): List<String> {
        val normalized = ocrText
            .uppercase()
            .replace("Ｏ", "0")
            .replace("１", "1")
            .replace("０", "0")
            .replace("Ａ", "A")
            .replace("Ｊ", "J")
            .replace("Ｑ", "Q")
            .replace("Ｋ", "K")
        return tokenRegex.findAll(normalized)
            .map { it.value.uppercase() }
            .filter { it in validRanks }
            .toList()
    }

    fun deckCountReport(ranks: List<String>): String {
        val counts = ranks.groupingBy { it }.eachCount()
        val limits = mapOf(
            "3" to 4, "4" to 4, "5" to 4, "6" to 4, "7" to 4,
            "8" to 4, "9" to 4, "10" to 4, "J" to 4, "Q" to 4,
            "K" to 4, "A" to 3, "2" to 1
        )
        val invalid = counts.filter { (rank, count) -> count > (limits[rank] ?: 0) }
        return if (invalid.isEmpty()) "点数候选 ${ranks.size} 个；牌库数量检查暂未发现超限"
        else "疑似误识别：${invalid.entries.joinToString { "${it.key}出现${it.value}次" }}"
    }
}

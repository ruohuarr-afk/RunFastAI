package com.runfast.camera

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import com.runfast.camera.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val processing = AtomicBoolean(false)

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else binding.statusText.text = "没有摄像头权限，请在系统设置中允许。"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        binding.statusText.text = "正在启动摄像头…请对准同事手机上的微乐跑得快游戏画面。"
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(cameraExecutor) { proxy ->
                val media = proxy.image
                if (media == null || !processing.compareAndSet(false, true)) { proxy.close(); return@setAnalyzer }
                recognizer.process(InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees))
                    .addOnSuccessListener { result ->
                        val ranks = CardRankParser.parse(result.text)
                        val raw = result.text.trim().replace("\n", " ")
                        runOnUiThread {
                            binding.statusText.text = buildString {
                                append("OCR原文：")
                                append(if (raw.isBlank()) "暂未识别到文字" else raw.take(150))
                                append("\n点数候选：")
                                append(if (ranks.isEmpty()) "暂无" else ranks.joinToString("、"))
                                append("\n")
                                append(CardRankParser.deckCountReport(ranks))
                                append("\n提示：当前为整幅画面文字候选，尚未区分手牌/出牌区。")
                            }
                        }
                    }
                    .addOnFailureListener { e -> runOnUiThread { binding.statusText.text = "识别失败：${e.localizedMessage}" } }
                    .addOnCompleteListener { processing.set(false); proxy.close() }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                binding.statusText.text = "摄像头已启动。请对准游戏画面，保持稳定并避免反光。"
            } catch (e: Exception) { binding.statusText.text = "摄像头启动失败：${e.localizedMessage}" }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        recognizer.close()
        cameraExecutor.shutdown()
    }
}

package com.runfast.manual

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val overlayRequest = 701
    private val captureRequest = 702
    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 40, 32, 32) }
        box.addView(TextView(this).apply {
            text = "跑得快 AI 1.4｜稳定性与横屏适配\n\n开始屏幕采集后，如果系统出现共享范围选项，请选择‘整个屏幕’，不要选择单个应用。系统选项由 Android 提供，应用无法替你预先选中。\n\n本版仅在本机内存中短暂保留最新一帧用于预览，不保存屏幕录像、不上传画面；暂不识别扑克牌、不自动出牌。故障诊断日志保存在应用私有目录。"
            textSize = 17f
        })
        box.addView(Button(this).apply {
            text = "开启悬浮助手"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), overlayRequest)
                } else startOverlay()
            }
        })
        box.addView(Button(this).apply {
            text = "授权并开始屏幕采集测试"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), overlayRequest)
                } else requestCapture()
            }
        })
        box.addView(Button(this).apply {
            text = "停止屏幕采集"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) }
        })
        val scroll = ScrollView(this).apply { addView(box) }
        setContentView(scroll)
    }

    private fun startOverlay() {
        startService(Intent(this, OverlayService::class.java))
        finish()
    }

    private fun requestCapture() {
        startActivityForResult(projectionManager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated in Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequest && Settings.canDrawOverlays(this)) startOverlay()
        if (requestCode == captureRequest) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(CaptureService.EXTRA_DATA, data)
                }
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
                startService(Intent(this, OverlayService::class.java))
                finish()
            }
        }
    }
}

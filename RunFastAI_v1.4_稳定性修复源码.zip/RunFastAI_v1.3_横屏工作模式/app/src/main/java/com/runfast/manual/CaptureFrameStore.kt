package com.runfast.manual

import android.graphics.Bitmap

/** Holds only the newest full frame and provisional crops in process memory. */
object CaptureFrameStore {
    @Volatile var latestBitmap: Bitmap? = null
    @Volatile var ownHandCrop: Bitmap? = null
    @Volatile var leftOpponentCrop: Bitmap? = null
    @Volatile var rightOpponentCrop: Bitmap? = null
    @Volatile var frameWidth: Int = 0
    @Volatile var frameHeight: Int = 0

    fun clearCrops() {
        listOf(ownHandCrop, leftOpponentCrop, rightOpponentCrop).forEach {
            if (it != null && !it.isRecycled) it.recycle()
        }
        ownHandCrop = null
        leftOpponentCrop = null
        rightOpponentCrop = null
    }
}

package com.runfast.manual

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Local diagnostic text only; never stores captured screen pixels or card contents. */
object DiagnosticLog {
    private const val TAG = "RunFastAI"
    @Synchronized
    fun write(context: Context, message: String, error: Throwable? = null) {
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
        val detail = buildString {
            append(time).append(" ").append(message)
            if (error != null) {
                append("\n").append(Log.getStackTraceString(error))
            }
            append("\n")
        }
        Log.e(TAG, detail)
        try {
            val file = File(context.filesDir, "runfast_diagnostics.log")
            file.appendText(detail)
            if (file.length() > 512 * 1024) {
                val lines = file.readLines().takeLast(1500)
                file.writeText(lines.joinToString("\n") + "\n")
            }
        } catch (writeError: Exception) {
            Log.e(TAG, "Unable to write diagnostic log", writeError)
        }
    }
}

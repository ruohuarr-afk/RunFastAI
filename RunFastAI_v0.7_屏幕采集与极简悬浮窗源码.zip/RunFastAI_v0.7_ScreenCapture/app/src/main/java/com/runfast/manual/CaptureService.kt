package com.runfast.manual

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "capture_result_code"
        const val EXTRA_DATA = "capture_data"
        const val ACTION_STATUS = "com.runfast.manual.CAPTURE_STATUS"
        private const val CHANNEL_ID = "runfast_capture"
        private const val NOTIFICATION_ID = 707
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var frameCount = 0L
    private var lastBroadcastAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_STICKY
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("正在准备屏幕采集"))
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        if (resultCode != 0 && data != null) startCapture(resultCode, data) else {
            sendStatus("未取得屏幕授权，请重新点击授权")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels.coerceAtLeast(1)
            val height = metrics.heightPixels.coerceAtLeast(1)
            val density = metrics.densityDpi
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            imageReader?.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage()
                if (image != null) {
                    frameCount++
                    image.close()
                    val now = System.currentTimeMillis()
                    if (now - lastBroadcastAt > 1200) {
                        lastBroadcastAt = now
                        sendStatus("屏幕采集中 · ${width}×${height} · 已获取${frameCount}帧")
                    }
                }
            }, mainHandler)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    sendStatus("屏幕采集已停止")
                    stopSelf()
                }
            }, mainHandler)
            virtualDisplay = projection?.createVirtualDisplay(
                "RunFastAI-Capture", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface, null, mainHandler
            )
            if (virtualDisplay == null) throw IllegalStateException("无法创建虚拟屏幕")
            sendStatus("屏幕采集已启动 · ${width}×${height}")
        } catch (e: Exception) {
            sendStatus("采集启动失败：${e.message ?: "未知错误"}")
            stopSelf()
        }
    }

    private fun sendStatus(message: String) {
        val update = Intent(ACTION_STATUS).setPackage(packageName).putExtra("status", message)
        sendBroadcast(update)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(message))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "跑得快AI屏幕采集", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("跑得快 AI 屏幕采集").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()
    }

    override fun onDestroy() {
        virtualDisplay?.release(); virtualDisplay = null
        imageReader?.close(); imageReader = null
        projection?.stop(); projection = null
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(NOTIFICATION_ID)
        sendStatus("屏幕采集已停止")
        super.onDestroy()
    }
}

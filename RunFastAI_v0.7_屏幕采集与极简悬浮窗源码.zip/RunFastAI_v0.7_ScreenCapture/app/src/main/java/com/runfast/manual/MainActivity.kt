package com.runfast.manual

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val overlayRequest = 701
    private val captureRequest = 702
    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 40, 32, 32) }
        box.addView(TextView(this).apply {
            text = "跑得快 AI 0.7｜屏幕采集测试\n\n本版先验证横屏游戏画面能否稳定采集，并优化为小圆点+窄面板。\n\n注意：本版只采集画面，不识别扑克牌、不自动出牌，也不会保存或上传屏幕内容。"
            textSize = 17f
        })
        box.addView(Button(this).apply {
            text = "开启悬浮助手"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), overlayRequest)
                } else startOverlay()
            }
        })
        box.addView(Button(this).apply {
            text = "授权并开始屏幕采集测试"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), overlayRequest)
                } else requestCapture()
            }
        })
        box.addView(Button(this).apply {
            text = "停止屏幕采集"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) }
        })
        setContentView(box)
    }

    private fun startOverlay() {
        startService(Intent(this, OverlayService::class.java))
        finish()
    }

    private fun requestCapture() {
        startActivityForResult(projectionManager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated in Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequest && Settings.canDrawOverlays(this)) startOverlay()
        if (requestCode == captureRequest) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(CaptureService.EXTRA_DATA, data)
                }
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
                startService(Intent(this, OverlayService::class.java))
                finish()
            }
        }
    }
}

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.runfast.manual"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.runfast.manual"
        minSdk = 26
        targetSdk = 35
        versionCode = 10
        versionName = "1.0-adjustable-crop"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}

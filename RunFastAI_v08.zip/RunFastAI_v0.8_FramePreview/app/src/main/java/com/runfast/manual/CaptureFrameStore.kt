package com.runfast.manual

import android.graphics.Bitmap

/** Holds only the newest frame in process memory; never writes screen content to disk. */
object CaptureFrameStore {
    @Volatile var latestBitmap: Bitmap? = null
    @Volatile var frameWidth: Int = 0
    @Volatile var frameHeight: Int = 0
}

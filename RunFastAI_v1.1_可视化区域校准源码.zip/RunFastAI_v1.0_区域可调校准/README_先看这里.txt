RunFastAI v1.1 可视化区域校准版

请先阅读 README_v1.1_说明.txt。

GitHub Actions 解压命令应指向本 ZIP 的文件名：
unzip -q "RunFastAI_v1.1_可视化区域校准源码.zip" -d source

本源码尚未在当前环境实际编译；上传后请以 GitHub Actions 的最新运行结果为准。

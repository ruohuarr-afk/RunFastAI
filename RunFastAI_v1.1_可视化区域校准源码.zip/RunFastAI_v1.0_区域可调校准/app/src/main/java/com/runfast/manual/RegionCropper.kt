package com.runfast.manual

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min

/** Adjustable normalized crop rectangles. Values persist locally on this device. */
object RegionCropper {
    data class Crops(val ownHand: Bitmap, val leftOpponent: Bitmap, val rightOpponent: Bitmap)
    data class Box(val l: Float, val t: Float, val r: Float, val b: Float)
    const val OWN = 0
    const val LEFT = 1
    const val RIGHT = 2
    private val defaults = arrayOf(
        Box(0.02f, 0.64f, 0.98f, 0.995f),
        Box(0.00f, 0.00f, 0.46f, 0.48f),
        Box(0.54f, 0.00f, 1.00f, 0.48f)
    )
    private const val PREFS = "crop_regions_v10"
    private fun key(i: Int, edge: String) = "r${i}_$edge"
    fun getBox(context: Context, index: Int): Box {
        val d = defaults[index]
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Box(p.getFloat(key(index,"l"),d.l), p.getFloat(key(index,"t"),d.t), p.getFloat(key(index,"r"),d.r), p.getFloat(key(index,"b"),d.b))
    }
    fun adjust(context: Context, index: Int, action: String) {
        val b = getBox(context,index)
        var l=b.l; var t=b.t; var r=b.r; var bottom=b.b
        val move=0.02f; val size=0.02f
        when(action) {
            "up" -> { t-=move; bottom-=move }; "down" -> { t+=move; bottom+=move }
            "left" -> { l-=move; r-=move }; "right" -> { l+=move; r+=move }
            "wider" -> { l-=size; r+=size }; "narrower" -> { l+=size; r-=size }
            "taller" -> { t-=size; bottom+=size }; "shorter" -> { t+=size; bottom-=size }
        }
        val minSize=0.06f
        l=l.coerceIn(0f,0.94f); r=r.coerceIn(l+minSize,1f)
        t=t.coerceIn(0f,0.94f); bottom=bottom.coerceIn(t+minSize,1f)
        context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit()
            .putFloat(key(index,"l"),l).putFloat(key(index,"t"),t).putFloat(key(index,"r"),r).putFloat(key(index,"b"),bottom).apply()
    }
    fun setBox(context: Context, index: Int, box: Box) {
        val l = box.l.coerceIn(0f, 0.94f)
        val t = box.t.coerceIn(0f, 0.94f)
        val r = box.r.coerceIn(l + 0.05f, 1f)
        val b = box.b.coerceIn(t + 0.05f, 1f)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat(key(index,"l"),l).putFloat(key(index,"t"),t)
            .putFloat(key(index,"r"),r).putFloat(key(index,"b"),b).apply()
    }
    fun reset(context: Context, index: Int) {
        context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().remove(key(index,"l")).remove(key(index,"t")).remove(key(index,"r")).remove(key(index,"b")).apply()
    }
    fun crop(frame: Bitmap, context: Context): Crops {
        fun make(i:Int): Bitmap {
            val b=getBox(context,i); val w=frame.width; val h=frame.height
            val left=(w*b.l).toInt().coerceIn(0,w-1); val top=(h*b.t).toInt().coerceIn(0,h-1)
            val right=(w*b.r).toInt().coerceIn(left+1,w); val bottom=(h*b.b).toInt().coerceIn(top+1,h)
            return Bitmap.createBitmap(frame,left,top,right-left,bottom-top)
        }
        return Crops(make(OWN),make(LEFT),make(RIGHT))
    }
}

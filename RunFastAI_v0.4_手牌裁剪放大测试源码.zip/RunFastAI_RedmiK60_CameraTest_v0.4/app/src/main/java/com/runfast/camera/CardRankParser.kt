package com.runfast.camera

/**
 * 从单个 OCR 文字块中提取跑得快点数。
 * 注意：这是 OCR 后处理，不是基于图像特征的完整扑克牌识别。
 */
object CardRankParser {
    private val tokenRegex = Regex("(?i)(10|[3-9]|[AJQK]|2)")
    private val validRanks = setOf("3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A", "2")

    fun parse(ocrText: String): List<String> {
        val normalized = ocrText.uppercase()
            .replace("Ｏ", "0")
            .replace("１", "1")
            .replace("０", "0")
            .replace("Ａ", "A")
            .replace("Ｊ", "J")
            .replace("Ｑ", "Q")
            .replace("Ｋ", "K")
        return tokenRegex.findAll(normalized)
            .map { it.value.uppercase() }
            .filter { it in validRanks }
            .toList()
    }

    fun deckCountReport(ranks: List<String>): String {
        val counts = ranks.groupingBy { it }.eachCount()
        val limits = mapOf(
            "3" to 4, "4" to 4, "5" to 4, "6" to 4, "7" to 4,
            "8" to 4, "9" to 4, "10" to 4, "J" to 4, "Q" to 4,
            "K" to 4, "A" to 3, "2" to 1
        )
        val invalid = counts.filter { (rank, count) -> count > (limits[rank] ?: 0) }
        return if (invalid.isEmpty()) {
            "牌库数量检查：暂未发现超限"
        } else {
            "疑似误识别：${invalid.entries.joinToString { "${it.key}出现${it.value}次" }}"
        }
    }
}

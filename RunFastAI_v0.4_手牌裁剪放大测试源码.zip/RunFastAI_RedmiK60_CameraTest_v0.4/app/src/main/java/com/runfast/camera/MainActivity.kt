package com.runfast.camera

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Rect
import androidx.camera.core.ImageProxy
import androidx.camera.core.toBitmap
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.runfast.camera.databinding.ActivityMainBinding
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val processing = AtomicBoolean(false)

    // 最近5次结果中至少3次完全一致，才作为稳定候选显示。
    private val recentResults = ArrayDeque<String>()
    private var stableRanks: List<String> = emptyList()
    private var lastStableKey: String = ""

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
            else binding.statusText.text = "没有摄像头权限，请在系统设置中允许。"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        binding.statusText.text = "正在启动摄像头…请让同事手机的手牌位于画面下方。"
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(cameraExecutor) { proxy ->
                val media = proxy.image
                if (media == null || !processing.compareAndSet(false, true)) {
                    proxy.close()
                    return@setAnalyzer
                }

                val rotation = proxy.imageInfo.rotationDegrees
                // 将摄像头画面转为位图，旋转校正后只截取底部手牌区域，并放大2倍再识别。
                // 这属于图像预处理 + OCR，不是训练好的扑克牌视觉模型。
                val sourceBitmap = proxy.toBitmap()
                val correctedBitmap = if (rotation == 0) sourceBitmap else {
                    val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                    Bitmap.createBitmap(sourceBitmap, 0, 0, sourceBitmap.width, sourceBitmap.height, matrix, true)
                }
                val cropTop = (correctedBitmap.height * 0.60f).toInt().coerceAtMost(correctedBitmap.height - 1)
                val handCrop = Bitmap.createBitmap(
                    correctedBitmap, 0, cropTop, correctedBitmap.width, correctedBitmap.height - cropTop
                )
                val enlarged = Bitmap.createScaledBitmap(handCrop, handCrop.width * 2, handCrop.height * 2, true)
                val image = InputImage.fromBitmap(enlarged, 0)

                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        // 输入图像已经裁剪到手牌区域，因此直接收集裁剪区内的文字元素。
                        val handElements = result.textBlocks
                            .flatMap { block -> block.lines }
                            .flatMap { line -> line.elements }
                            .sortedBy { it.boundingBox?.centerX() ?: Int.MAX_VALUE }

                        val ranks = handElements.flatMap { CardRankParser.parse(it.text) }
                        val key = ranks.joinToString(",")

                        runOnUiThread {
                            updateStableResult(ranks, key, handElements.size)
                        }
                        if (correctedBitmap !== sourceBitmap) correctedBitmap.recycle()
                        if (sourceBitmap !== correctedBitmap) sourceBitmap.recycle()
                        handCrop.recycle()
                        enlarged.recycle()
                    }
                    .addOnFailureListener { e ->
                        runOnUiThread {
                            binding.statusText.text = "识别失败：${e.localizedMessage}"
                        }
                    }
                    .addOnCompleteListener {
                        processing.set(false)
                        proxy.close()
                    }
            }

            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis
                )
                binding.statusText.text =
                    "摄像头已启动。请让整排手牌位于画面下方约40%区域，尽量靠近、对焦清晰并避免反光。"
            } catch (e: Exception) {
                binding.statusText.text = "摄像头启动失败：${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updateStableResult(ranks: List<String>, key: String, elementCount: Int) {
        recentResults.addLast(key)
        while (recentResults.size > 5) recentResults.removeFirst()

        val occurrences = recentResults.count { it == key }
        val isStable = key.isNotBlank() && occurrences >= 3

        if (isStable) {
            stableRanks = ranks
            lastStableKey = key
            binding.statusText.text = buildString {
                append("手牌区域识别：已稳定（最近5次中有3次一致）\n")
                append("识别到 ${stableRanks.size} 张候选牌：")
                append(stableRanks.joinToString("、"))
                append("\n")
                append(CardRankParser.deckCountReport(stableRanks))
                append("\n提示：这是手牌区域的文字候选，不代表每张牌都已确认。")
            }
        } else {
            val previous = if (lastStableKey.isBlank()) "暂无稳定结果"
                else "上次稳定结果：${stableRanks.joinToString("、")}"
            binding.statusText.text = buildString {
                append("正在稳定识别…（当前区域文字块：${elementCount}）\n")
                append(previous)
                append("\n当前帧候选：")
                append(if (ranks.isEmpty()) "暂无" else ranks.joinToString("、"))
                append("\n请保持镜头和手牌不动，等待多帧一致。")
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        recognizer.close()
        cameraExecutor.shutdown()
    }
}

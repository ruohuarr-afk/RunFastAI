package com.runfast.manual

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,48,32,32) }
        box.addView(TextView(this).apply {
            text = "跑得快 AI 0.5｜悬浮窗手动录入\n\n不读取游戏屏幕，不使用摄像头。你手动录入自己的手牌和对手打出的牌。"
            textSize = 18f
        })
        box.addView(Button(this).apply {
            text = "开启悬浮窗"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                }
            }
        })
        box.addView(Button(this).apply {
            text = "使用说明"
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("使用说明")
                    .setMessage("进入游戏前开启悬浮窗。悬浮面板可录入自己的手牌、记录对手出牌和过牌。当前版本先做手动记录与剩余牌数统计，暂不自动读取画面，也暂不提供未经验证的策略推荐。")
                    .setPositiveButton("知道了", null).show()
            }
        })
        setContentView(box)
    }
}

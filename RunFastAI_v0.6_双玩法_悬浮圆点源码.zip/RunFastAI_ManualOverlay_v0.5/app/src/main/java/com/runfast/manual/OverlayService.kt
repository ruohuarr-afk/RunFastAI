package com.runfast.manual

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var bubble: TextView? = null
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private val hand = mutableListOf<String>()
    private val played = mutableListOf<String>()
    private val ranks = listOf("3","4","5","6","7","8","9","10","J","Q","K","A","2")
    private var is16 = true
    private var inputMode = "手牌"
    private lateinit var summary: TextView
    private lateinit var ruleLine: TextView

    private fun limit(rank: String): Int = when (rank) {
        "A" -> if (is16) 3 else 1
        "K" -> if (is16) 4 else 3
        "2" -> 1
        else -> 4
    }
    private val handMax get() = if (is16) 16 else 15
    private val deckSize get() = if (is16) 48 else 45

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null && bubble == null) showBubble()
        return START_STICKY
    }

    private fun windowType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bubbleParams = WindowManager.LayoutParams(dp(54), dp(54), windowType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END; x = dp(14); y = dp(180)
        }
        val b = TextView(this).apply {
            text = "AI"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xDD1565C0.toInt()); setStroke(dp(2), Color.WHITE) }
            setOnClickListener { removeBubble(); showPanel() }
        }
        bubble = b
        wm.addView(b, bubbleParams)
        makeDraggable(b, bubbleParams)
    }

    private fun removeBubble() { bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null }
    private fun showPanel() {
        panelParams = WindowManager.LayoutParams((resources.displayMetrics.widthPixels * .92f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT, windowType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(70) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),dp(10),dp(12),dp(10)); background = GradientDrawable().apply { setColor(0xF2FFFFFF.toInt()); cornerRadius = dp(14).toFloat(); setStroke(dp(1),0xFF888888.toInt()) } }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply { text = "跑得快 AI 助手"; textSize=17f; setTextColor(0xFF111111.toInt()) }, LinearLayout.LayoutParams(0,-2,1f))
        top.addView(Button(this).apply { text="收起"; setOnClickListener { collapse() } })
        top.addView(Button(this).apply { text="关闭"; setOnClickListener { stopSelf() } })
        box.addView(top)
        val gameRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        gameRow.addView(Button(this).apply { text="16张经典"; setOnClickListener { setGame(true) } }, LinearLayout.LayoutParams(0,-2,1f))
        gameRow.addView(Button(this).apply { text="15张玩法"; setOnClickListener { setGame(false) } }, LinearLayout.LayoutParams(0,-2,1f))
        box.addView(gameRow)
        val tabs = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        tabs.addView(Button(this).apply { text="录入我的手牌"; setOnClickListener { inputMode="手牌"; refresh() } }, LinearLayout.LayoutParams(0,-2,1f))
        tabs.addView(Button(this).apply { text="记录对手出牌"; setOnClickListener { inputMode="对手出牌"; refresh() } }, LinearLayout.LayoutParams(0,-2,1f))
        box.addView(tabs)
        summary = TextView(this).apply { textSize=13f; setTextColor(0xFF222222.toInt()); setPadding(0,dp(6),0,dp(6)) }
        box.addView(summary)
        val grid=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        ranks.chunked(7).forEach { chunk ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            chunk.forEach { r -> row.addView(Button(this).apply { text=r; textSize=12f; setPadding(0,0,0,0); setOnClickListener { addCard(r) } }, LinearLayout.LayoutParams(0,-2,1f)) }
            grid.addView(row)
        }
        box.addView(grid)
        val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply { text="撤销"; setOnClickListener { if(inputMode=="手牌") { if(hand.isNotEmpty()) hand.removeAt(hand.lastIndex) } else if(played.isNotEmpty()) played.removeAt(played.lastIndex); refresh() } }, LinearLayout.LayoutParams(0,-2,1f))
        actions.addView(Button(this).apply { text="清空当前"; setOnClickListener { if(inputMode=="手牌") hand.clear() else played.clear(); refresh() } }, LinearLayout.LayoutParams(0,-2,1f))
        actions.addView(Button(this).apply { text="重置本局"; setOnClickListener { hand.clear(); played.clear(); refresh() } }, LinearLayout.LayoutParams(0,-2,1f))
        box.addView(actions)
        ruleLine=TextView(this).apply { textSize=10f; setTextColor(0xFF555555.toInt()) }
        box.addView(ruleLine)
        panel=box; wm.addView(box,panelParams); refresh()
    }

    private fun addCard(r: String) {
        val used=hand.count{it==r}+played.count{it==r}
        if(used>=limit(r)) return
        if(inputMode=="手牌") { if(hand.size<handMax) hand.add(r) } else played.add(r)
        refresh()
    }
    private fun setGame(classic:Boolean) { if(is16==classic) return; is16=classic; hand.clear(); played.clear(); refresh() }
    private fun refresh() {
        if(!::summary.isInitialized) return
        val own=hand.groupingBy{it}.eachCount().entries.sortedBy{ranks.indexOf(it.key)}.joinToString("  "){ "${it.key}×${it.value}" }.ifBlank{"尚未录入"}
        val out=played.groupingBy{it}.eachCount().entries.sortedBy{ranks.indexOf(it.key)}.joinToString("  "){ "${it.key}×${it.value}" }.ifBlank{"暂无"}
        val remain=deckSize-hand.size-played.size
        summary.text="玩法：${if(is16)"16张经典" else "15张玩法"}    当前录入：$inputMode\n我的手牌：${hand.size}/$handMax\n$own\n对手已出：${played.size}张\n$out\n剩余未知牌：${remain.coerceAtLeast(0)}张"
        ruleLine.text="牌库：${if(is16)"3-K各4张，A×3，2×1（48张）" else "3-Q各4张，K×3，A×1，2×1（45张）"}\n当前版本：手动录入与牌数核对；尚未实现完整牌型判断、对手推理和策略推荐。"
    }
    private fun collapse() { panel?.let { try { wm.removeView(it) } catch (_:Exception){} }; panel=null; showBubble() }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun makeDraggable(view: android.view.View, params: WindowManager.LayoutParams) {
        var sx=0f; var sy=0f; var ox=0; var oy=0
        view.setOnTouchListener { _,e -> when(e.action) {
            MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=params.x; oy=params.y; true }
            MotionEvent.ACTION_MOVE -> { params.x=ox-(e.rawX-sx).toInt(); params.y=oy+(e.rawY-sy).toInt(); try{wm.updateViewLayout(view,params)}catch(_:Exception){}; true }
            MotionEvent.ACTION_UP -> { val dx=kotlin.math.abs(e.rawX-sx); val dy=kotlin.math.abs(e.rawY-sy); if(dx<8 && dy<8) view.performClick(); true }
            else -> true
        } }
    }
    override fun onDestroy() {
        panel?.let { try{wm.removeView(it)}catch(_:Exception){} }; bubble?.let { try{wm.removeView(it)}catch(_:Exception){} }; panel=null; bubble=null
        super.onDestroy()
    }
}

RunFastAI v1.4 - Stability & Full-screen Capture

基于用户提供的 v1.3 横屏源码进行修改。

主要改动：
1. 版本号更新为 1.4 / versionCode 14。
2. MediaProjection 继续使用系统屏幕采集授权流程，按整个显示屏创建 VirtualDisplay（AUTO_MIRROR）；Android 14+ 的系统范围选择由系统控制，若弹窗提供范围选项，用户应选择“整个屏幕”。应用不绕过系统授权，也不强制选择范围。
3. 新增 RunFastLogger，日志保存在应用私有目录 files/logs/runfastai.log，超过约 512 KiB 时滚动保留上一份日志；记录未捕获异常并交给系统原异常处理器。
4. CaptureService 增加生命周期日志、异常堆栈、重复清理保护、资源逐项安全释放；停止时不再取消通知后重新发送状态通知。
5. CaptureFrameStore 不再主动 recycle 可能仍被悬浮窗 View 引用的旧 Bitmap；替换引用后由 GC 回收，避免 UI 持有已 recycle Bitmap。
6. 横屏悬浮校准面板改为固定可视高度的 ScrollView，所有现有校准按钮可滚动访问。
7. 保留三个区域及其原始默认坐标、SharedPreferences key 和校准操作。

重要限制：
- Android 系统授权弹窗中的“整个屏幕/单个应用”选项由系统管理。应用只能请求 MediaProjection 并提示用户选择，不能代替用户选择。
- Android 若直接杀死进程，系统可能不调用 Service.onDestroy；因此本地日志不能保证捕获所有系统级终止原因。
- 此源码包尚未在 Android SDK/Gradle 环境中实际编译，也未在设备实测。请通过 GitHub Actions 编译后再安装测试。
- 本项目仍是屏幕采集与区域校准测试工具；自动识牌和自动出牌尚未实现。

package com.runfast.manual

import android.content.Context
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Small, bounded, app-private diagnostic log. */
object RunFastLogger {
    private const val TAG = "RunFastAI"
    private const val MAX_BYTES = 512 * 1024L
    @Volatile private var appContext: Context? = null
    @Synchronized fun initialize(context: Context) { appContext = context.applicationContext }
    fun info(component: String, message: String) = write("I", component, message, null)
    fun error(component: String, message: String, error: Throwable? = null) = write("E", component, message, error)
    @Synchronized private fun write(level: String, component: String, message: String, error: Throwable?) {
        val line = buildString {
            append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date()))
            append(" [").append(level).append("] [").append(component).append("] [")
            append(Thread.currentThread().name).append("] ").append(message)
            if (error != null) {
                val sw = StringWriter(); error.printStackTrace(PrintWriter(sw))
                append("\n").append(sw.toString())
            }
            append("\n")
        }
        if (level == "E") Log.e(TAG, "$component: $message", error) else Log.i(TAG, "$component: $message")
        try {
            val ctx = appContext ?: return
            val dir = File(ctx.filesDir, "logs").apply { mkdirs() }
            val file = File(dir, "runfastai.log")
            if (file.exists() && file.length() > MAX_BYTES) {
                val old = File(dir, "runfastai.previous.log")
                if (old.exists()) old.delete()
                file.renameTo(old)
            }
            file.appendText(line)
        } catch (t: Throwable) { Log.e(TAG, "Unable to write diagnostic log", t) }
    }
}

class RunFastApplication : android.app.Application() {
    override fun onCreate() {
        super.onCreate()
        RunFastLogger.initialize(this)
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            RunFastLogger.error("Crash", "Uncaught exception on ${thread.name}", error)
            previous?.uncaughtException(thread, error)
        }
        RunFastLogger.info("Application", "process started")
    }
}

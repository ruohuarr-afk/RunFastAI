package com.runfast.manual

import android.graphics.Bitmap

/** Latest frame/crops shared with UI. Updates run on the main handler; replaced bitmaps are left
 * for GC because Views may still hold the previous reference until their next UI update. */
object CaptureFrameStore {
    @Volatile var latestBitmap: Bitmap? = null
    @Volatile var ownHandCrop: Bitmap? = null
    @Volatile var leftOpponentCrop: Bitmap? = null
    @Volatile var rightOpponentCrop: Bitmap? = null
    @Volatile var frameWidth: Int = 0
    @Volatile var frameHeight: Int = 0

    @Synchronized fun publishFrame(frame: Bitmap, crops: RegionCropper.Crops) {
        latestBitmap = frame
        frameWidth = frame.width
        frameHeight = frame.height
        ownHandCrop = crops.ownHand
        leftOpponentCrop = crops.leftOpponent
        rightOpponentCrop = crops.rightOpponent
    }

    @Synchronized fun clear() {
        latestBitmap = null
        ownHandCrop = null
        leftOpponentCrop = null
        rightOpponentCrop = null
        frameWidth = 0
        frameHeight = 0
    }

    @Synchronized fun clearCrops() {
        ownHandCrop = null
        leftOpponentCrop = null
        rightOpponentCrop = null
    }
}

package com.runfast.manual

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "capture_result_code"
        const val EXTRA_DATA = "capture_data"
        const val ACTION_STATUS = "com.runfast.manual.CAPTURE_STATUS"
        private const val CHANNEL_ID = "runfast_capture"
        private const val NOTIFICATION_ID = 707
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var frameCount = 0L
    private var lastBroadcastAt = 0L
    private var lastPreviewAt = 0L
    @Volatile private var stopRequested = false
    @Volatile private var cleaned = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        RunFastLogger.info("CaptureService", "onCreate")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        RunFastLogger.info("CaptureService", "onStartCommand startId=$startId")
        if (projection != null) return START_NOT_STICKY
        createNotificationChannel()
        try {
            startForeground(NOTIFICATION_ID, buildNotification("正在准备屏幕采集"))
            val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
            val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
            if (resultCode != 0 && data != null) startCapture(resultCode, data) else {
                RunFastLogger.error("CaptureService", "missing MediaProjection permission result")
                sendStatus("未取得屏幕授权，请重新点击授权")
                stopSelf(startId)
            }
        } catch (t: Throwable) {
            RunFastLogger.error("CaptureService", "onStartCommand failed", t)
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            val display = (getSystemService(WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay
            @Suppress("DEPRECATION")
            display.getRealMetrics(metrics)
            var width = metrics.widthPixels.coerceAtLeast(1)
            var height = metrics.heightPixels.coerceAtLeast(1)
            val density = metrics.densityDpi
            val rotation = display.rotation
            if ((rotation == android.view.Surface.ROTATION_90 || rotation == android.view.Surface.ROTATION_270) && height > width) {
                val tmp = width; width = height; height = tmp
            }
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            imageReader?.setOnImageAvailableListener({ reader ->
                var image: android.media.Image? = null
                try {
                    image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                    frameCount++
                    val now = System.currentTimeMillis()
                    if (now - lastPreviewAt > 1000 && !stopRequested) {
                        lastPreviewAt = now
                        val plane = image.planes[0]
                        val pixelStride = plane.pixelStride
                        val rowStride = plane.rowStride
                        val paddedWidth = (rowStride / pixelStride).coerceAtLeast(image.width)
                        val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
                        try {
                            val buffer = plane.buffer
                            buffer.rewind()
                            padded.copyPixelsFromBuffer(buffer)
                            val frame = if (paddedWidth != image.width) {
                                Bitmap.createBitmap(padded, 0, 0, image.width, image.height).also { padded.recycle() }
                            } else padded
                            try {
                                val crops = RegionCropper.crop(frame, this)
                                CaptureFrameStore.publishFrame(frame, crops)
                            } catch (t: Throwable) {
                                if (!frame.isRecycled) frame.recycle()
                                throw t
                            }
                        } catch (t: Throwable) {
                            if (!padded.isRecycled) padded.recycle()
                            throw t
                        }
                    }
                    if (now - lastBroadcastAt > 1200) {
                        lastBroadcastAt = now
                        sendStatus("屏幕采集中 · 实际画面${image.width}×${image.height} · 已获取${frameCount}帧")
                    }
                } catch (t: Throwable) {
                    RunFastLogger.error("ImageReader", "frame processing failed", t)
                    if (t is OutOfMemoryError) sendStatus("内存不足，已暂停本帧预览；请关闭其他应用后重试")
                    else sendStatus("画面预览处理异常，详情已写入本地日志")
                } finally {
                    try { image?.close() } catch (t: Throwable) { RunFastLogger.error("ImageReader", "image close failed", t) }
                }
            }, mainHandler)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    RunFastLogger.info("MediaProjection", "system projection stopped")
                    sendStatus("系统已停止屏幕采集")
                    stopRequested = true
                    stopSelf()
                }
            }, mainHandler)
            virtualDisplay = projection?.createVirtualDisplay(
                "RunFastAI-Capture", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface, null, mainHandler
            )
            if (virtualDisplay == null) throw IllegalStateException("无法创建虚拟屏幕")
            RunFastLogger.info("CaptureService", "capture started ${width}x${height}, rotation=$rotation; full-display MediaProjection")
            sendStatus("全屏采集已启动 · ${if (width >= height) "横屏" else "竖屏"} · ${width}×${height} · 旋转${rotation * 90}°")
        } catch (t: Throwable) {
            RunFastLogger.error("CaptureService", "capture startup failed", t)
            sendStatus("采集启动失败，详情已写入本地日志")
            stopRequested = true
            stopSelf()
        }
    }

    private fun sendStatus(message: String) {
        try {
            sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra("status", message))
            if (!cleaned) {
                val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(NOTIFICATION_ID, buildNotification(message))
            }
        } catch (t: Throwable) { RunFastLogger.error("CaptureService", "sendStatus failed", t) }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "跑得快AI屏幕采集", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("跑得快 AI 屏幕采集").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        RunFastLogger.info("CaptureService", "onTaskRemoved")
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        if (cleaned) { super.onDestroy(); return }
        cleaned = true
        stopRequested = true
        RunFastLogger.info("CaptureService", "onDestroy begin")
        try { imageReader?.setOnImageAvailableListener(null, null) } catch (t: Throwable) { RunFastLogger.error("CaptureService", "detach ImageReader listener failed", t) }
        try { virtualDisplay?.release() } catch (t: Throwable) { RunFastLogger.error("CaptureService", "VirtualDisplay release failed", t) }
        virtualDisplay = null
        try { imageReader?.close() } catch (t: Throwable) { RunFastLogger.error("CaptureService", "ImageReader close failed", t) }
        imageReader = null
        // Do not recycle here: overlay Views may still hold these bitmaps. Dropping store refs
        // lets the old frames be reclaimed safely after the UI releases them.
        CaptureFrameStore.clear()
        val oldProjection = projection
        projection = null
        try { oldProjection?.stop() } catch (t: Throwable) { RunFastLogger.error("CaptureService", "MediaProjection stop failed", t) }
        try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIFICATION_ID) }
        catch (t: Throwable) { RunFastLogger.error("CaptureService", "notification cancel failed", t) }
        RunFastLogger.info("CaptureService", "onDestroy complete")
        super.onDestroy()
    }
}

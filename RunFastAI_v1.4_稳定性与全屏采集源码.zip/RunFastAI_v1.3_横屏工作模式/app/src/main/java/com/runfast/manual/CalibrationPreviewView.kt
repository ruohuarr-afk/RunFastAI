package com.runfast.manual

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Full-frame preview with draggable crop rectangles. Drag inside a box to move it;
 * drag the small bottom-right handle to resize it. Coordinates are normalized to the source frame. */
class CalibrationPreviewView(context: Context) : View(context) {
    private var frame: Bitmap? = null
    var selectedRegion: Int = RegionCropper.OWN
        set(value) { field = value; invalidate() }
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; alpha = 34 }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(2f) }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val colors = intArrayOf(Color.CYAN, Color.GREEN, 0xFFFF9800.toInt())
    private var imageRect = RectF()
    private var active = -1
    private var resizing = false
    private var lastX = 0f
    private var lastY = 0f
    private fun dp(v: Float) = v * resources.displayMetrics.density

    fun setFrame(bitmap: Bitmap?) { frame = bitmap; invalidate() }

    private fun mapped(box: RegionCropper.Box): RectF = RectF(
        imageRect.left + box.l * imageRect.width(), imageRect.top + box.t * imageRect.height(),
        imageRect.left + box.r * imageRect.width(), imageRect.top + box.b * imageRect.height()
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)
        val bmp = frame
        if (bmp == null || bmp.isRecycled) {
            canvas.drawText("等待屏幕画面…", dp(12f), dp(24f), Paint().apply { color = Color.WHITE; textSize = dp(12f) })
            return
        }
        val scale = min(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
        val w = bmp.width * scale; val h = bmp.height * scale
        imageRect = RectF((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
        canvas.drawBitmap(bmp, null, imageRect, imagePaint)
        for (i in 0..2) {
            val r = mapped(RegionCropper.getBox(context, i))
            fillPaint.color = colors[i]; strokePaint.color = colors[i]; handlePaint.color = colors[i]
            fillPaint.alpha = if (i == selectedRegion) 48 else 20
            strokePaint.strokeWidth = dp(if (i == selectedRegion) 3f else 1.5f)
            canvas.drawRect(r, fillPaint); canvas.drawRect(r, strokePaint)
            canvas.drawCircle(r.right, r.bottom, dp(if (i == selectedRegion) 7f else 4f), handlePaint)
            val label = arrayOf("我的手牌", "左侧对手", "右侧对手")[i]
            val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = dp(11f); setShadowLayer(dp(2f), 0f, 0f, Color.BLACK) }
            canvas.drawText(label, r.left + dp(3f), (r.top + dp(14f)).coerceAtMost(r.bottom), text)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x; lastY = event.y
                active = selectedRegion
                val r = mapped(RegionCropper.getBox(context, active))
                resizing = event.x >= r.right - dp(24f) && event.y >= r.bottom - dp(24f)
                if (!r.contains(event.x, event.y)) {
                    var found = -1
                    for (i in 0..2) if (mapped(RegionCropper.getBox(context, i)).contains(event.x, event.y)) found = i
                    if (found >= 0) { active = found; selectedRegion = found; resizing = false }
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (active !in 0..2 || imageRect.width() <= 0f || imageRect.height() <= 0f) return true
                val dx = (event.x - lastX) / imageRect.width()
                val dy = (event.y - lastY) / imageRect.height()
                val b = RegionCropper.getBox(context, active)
                val next = if (resizing) RegionCropper.Box(b.l, b.t, (b.r + dx).coerceIn(b.l + .05f, 1f), (b.b + dy).coerceIn(b.t + .05f, 1f))
                    else {
                        val ww = b.r - b.l; val hh = b.b - b.t
                        val l = (b.l + dx).coerceIn(0f, 1f - ww); val t = (b.t + dy).coerceIn(0f, 1f - hh)
                        RegionCropper.Box(l, t, l + ww, t + hh)
                    }
                RegionCropper.setBox(context, active, next)
                lastX = event.x; lastY = event.y; invalidate(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { active = -1; return true }
        }
        return true
    }
}

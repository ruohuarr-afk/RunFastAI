RunFastAI v1.3 横屏工作模式源码

请使用 GitHub Actions 编译。workflow 的 unzip 文件名需要指向：
RunFastAI_v1.3_横屏工作模式源码.zip

本版主界面固定横屏，悬浮校准面板改为宽屏居中布局。保留实时采集预览和三个区域拖动/缩放校准。
尚未完成本地 Gradle 编译及实机验证；自动识牌、记牌和出牌推荐尚未实现。
